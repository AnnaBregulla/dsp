# -*- coding: utf-8 -*-
"""
Created on Sat Nov 14 11:56:20 2020

@author: bregu
"""

class IIR2Filter: # 2nd order IIR filter
    
    def __init__(self,_b0, _b1, _b2, _a1, _a2):
        self.b0 = _b0 # fir coef
        self.b1 = _b1
        self.b2 = _b2
        self.a1 = _a1 # iir coef
        self.a2 = _a2
        
        self.buffer1 = 0
        self.buffer2 = 0
         
    def filter(self, x):
        y_in = x - self.buffer1*self.a1 - self.buffer2*self.a2
        y_out = y_in*self.b0 + self.buffer1*self.b1 + self.buffer2*self.b2
       
        self.buffer2 = self.buffer1
        self.buffer1 = y_in
    
        return y_out