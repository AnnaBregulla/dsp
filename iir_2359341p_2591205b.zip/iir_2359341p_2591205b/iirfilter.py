# -*- coding: utf-8 -*-
"""
Created on Thu Nov 19 17:24:54 2020

@author: bregu
"""

import iir2filter

class IIRFilter:
    
    def __init__(self, sos_array):
        self.arrayOfIrr2filters = []
        
        for i in range(len(sos_array[:,0])): # create chain of 2nd order irr filters, saved in an array
            irr2filter = iir2filter.IIR2Filter(sos_array[i,0], sos_array[i,1], sos_array[i,2], sos_array[i,4], sos_array[i,5])
            self.arrayOfIrr2filters.append(irr2filter)
            
    def filter(self, x): # filter input value x by sending it through a chain of 2nd order iir filters
        y = self.arrayOfIrr2filters[0].filter(x) 
        
        for i in range(1, len(self.arrayOfIrr2filters)):   
            y = self.arrayOfIrr2filters[i].filter(y)  
            
        return y