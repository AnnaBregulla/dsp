import matplotlib.pyplot as plt
import matplotlib.animation as animation
import scipy.signal as signal
import numpy as np
import webcam2rgb
import iirfilter
import nanotime

class RealtimePlotWindow: # from github + some changes marked with "#changed" (https://github.com/berndporr/webcam2rgb/blob/main/demo.py)
  
    def __init__(self, channel: str, _dataToPlot):                      #changed
        self.dataToPlot = _dataToPlot
        # create a plot window
        self.fig, self.ax = plt.subplots()
        plt.title(f"Channel: {channel}")
        # that's our plotbuffer
        self.plotbuffer = np.zeros(500)
        # create an empty line
        self.line, = self.ax.plot(self.plotbuffer)
        # axis
        if (self.dataToPlot == "filtered"):                             #changed
            self.ax.set_ylim(0, 1200)                                   #changed
            self.ax.set_ylabel("Amplitude")                             #changed
            self.ax.set_xlabel("Samples")                               #changed
                         
        if (self.dataToPlot == "strokeFrequency"):                      #changed
            self.ax.set_ylim(0, 240)                                    #changed   
            self.ax.set_ylabel("Stroke Frequency [bmp]")                #changed   
            self.ax.set_xlabel("Samples")                               #changed   
        # That's our ringbuffer which accumluates the samples
        # It's emptied every time when the plot window below
        # does a repaint
        self.ringbuffer = []
        # add any initialisation code here (filters etc)
        # start the animation
        self.ani = animation.FuncAnimation(self.fig, self.update, interval=100)
        
    # updates the plot
    def update(self, data):
        # add new data to the buffer
        self.plotbuffer = np.append(self.plotbuffer, self.ringbuffer)
        # only keep the 500 newest ones and discard the old ones
        self.plotbuffer = self.plotbuffer[-500:] 
        self.ringbuffer = []
        # set the new 500 points of channel 9
        self.line.set_ydata(self.plotbuffer)
        if (self.dataToPlot == "original"):                                         #changed   
            self.ax.set_ylim(min(self.plotbuffer)-1, max(self.plotbuffer)+1)        #changed
            self.ax.set_ylabel("RGB value detected from Camera")                    #changed
            self.ax.set_xlabel("Samples")                                           #changed    
        
        return self.line,

    # appends data to the ringbuffer
    def addData(self, v):
        self.ringbuffer.append(v)
        
#### plot windows for real time processing ####
realtimePlotWindowBlueOriginal = RealtimePlotWindow("Blue Original", "original")                   #changed   
realtimePlotWindowGreenOriginal = RealtimePlotWindow("Green Original", "original")                 #changed   
realtimePlotWindowRedOriginal = RealtimePlotWindow("Red Original", "original")                     #changed   
realtimePlotWindowBlueFiltered = RealtimePlotWindow("Blue Filtered", "filtered")                   #changed   
realtimePlotWindowGreenFiltered = RealtimePlotWindow("Green Filtered","filtered")                  #changed   
realtimePlotWindowRedFiltered = RealtimePlotWindow("Red Filtered", "filtered")                     #changed   
realtimePlotWindowStrokeFrequency = RealtimePlotWindow("Strike Frequency", "strokeFrequency")      #changed   

#create callback method reading camera and plotting in windows
#changed
def hasData(retval, data): 
    global f_samplerate
    global timeBetweenSamples
    global indexNewestSample
    global buffer_indexOfDetectedStroke
    global _10seconds
    global startDone
    global start_cameraTime
    global strokeFrequency
   
    if startDone == True: # just jumping in here when the first sample is taken
        startDone = False
        start_cameraTime = nanotime.now() 
        
    end_cameraTime = nanotime.now() # update every time new sample is taken
    
    blue = data[0]
    filtered_blue = filter_BP.filter(blue) # filter blue part of pixel
   
    green = data[1]
    filtered_green = filter_BP.filter(green) # filter green part of pixel
   
    red = data[2]
    filtered_red = filter_BP.filter(red) # filter red part of pixel
        
    time = (end_cameraTime - start_cameraTime).seconds() # time between first and newest sample
    
    if (time > 10) and (_10seconds == True): # if 10 seconds reached: printing comparison of expected vs actual number of samples
        print("samples after 10 seconds: ", indexNewestSample+1, "; expected samples: ", 10*f_samplerate)
        _10seconds = False # make sure command above is just printed once
  
    timePeriodBetweenStrokes = (buffer_indexOfDetectedStroke[1] - buffer_indexOfDetectedStroke[0]) * timeBetweenSamples # s
 
    # detection of new stroke & calculation of stroke frequency 
    if((filtered_green**2  > 200) and (abs(buffer_indexOfDetectedStroke[1] - indexNewestSample) > 7)): # 7 indizes correspond to about 4.3 Hz (only frequencies below will be considered)

        if(timePeriodBetweenStrokes != 0):
            strokeFrequency = 1 / timePeriodBetweenStrokes * 60 /2 # bpm /2 because of up- and downward transition of stroke  
            #print(strokeFrequency)
        indexOldestSample = buffer_indexOfDetectedStroke[1] 
        buffer_indexOfDetectedStroke[1] = indexNewestSample
        buffer_indexOfDetectedStroke[0] = indexOldestSample
        
    indexNewestSample += 1
   
    realtimePlotWindowBlueOriginal.addData(blue)
    realtimePlotWindowGreenOriginal.addData(green)
    realtimePlotWindowRedOriginal.addData(red)
    realtimePlotWindowBlueFiltered.addData(filtered_blue**2)    
    realtimePlotWindowGreenFiltered.addData(filtered_green**2)
    realtimePlotWindowRedFiltered.addData(filtered_red**2)
    realtimePlotWindowStrokeFrequency.addData(strokeFrequency)
 
    
# creating bandpass butterworth filter 
f_start = 1 # Hz 
f_end = 4   # Hz
f_samplerate = 30 # Hz                     (using it in function "hasData(retval, data)" (see above))
timeBetweenSamples = 1 / f_samplerate # s  (using it in function "hasData(retval, data)" (see above))
f_Python_start = f_start / f_samplerate * 2 # normalized frequency for Python (f = 0...1)
f_Python_end = f_end / f_samplerate * 2     # normalized frequency for Python (f = 0...1)
orderFilter = 6
sos = signal.butter(orderFilter, [f_Python_start, f_Python_end], btype ='bandpass', output = 'sos') # coefficients of 2nd order iir filters

filter_BP = iirfilter.IIRFilter(sos) # bandpass filter

# initialisation for values, used in function "hasData(retval, data)"
indexNewestSample = 0
buffer_indexOfDetectedStroke = np.array([0, 0])
_10seconds = True
startDone = True
strokeFrequency = 0

#create instances of camera
camera = webcam2rgb.Webcam2rgb()
#start the thread and stop it when we close the plot windows
camera.start(callback = hasData, cameraNumber = 0)
print("camera samplerate: ", camera.cameraFs(), "Hz")
plt.show()
print('finished')
camera.stop()